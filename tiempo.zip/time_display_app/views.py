from django.shortcuts import render, redirect,HttpResponse
from time import gmtime, strftime
# Create your views here.

def hola(request):
    return HttpResponse('funciona') 

def index(request):
    context = {
        "time": strftime("%b %d,%Y %X ", gmtime())
    }
    return render(request,'tiempo.html', context)

